/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trabalho3;

/**
 *
 * @author riche
 */
class Computador implements Jogador {
    private Personagem personagem;

    public Computador(Personagem personagem) {
        this.personagem = personagem;
    }

    @Override
    public void atacar(Personagem p) {
        personagem.atacar(p);
    }

    @Override
    public void curar() {
        personagem.curar();
    }

    public Personagem getPersonagem() {
        return personagem;
    }
}
