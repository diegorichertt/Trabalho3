/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.trabalho3;

/**
 *
 * @author riche
 */
import java.util.Scanner;

public class Trabalho3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Criar personagens
        Usuario usuario = new Usuario(new Fogo("Usuário Fogo", 50));
        Computador computador = new Computador(new Agua("Computador Água", 50));

        // Loop do jogo
        while (usuario.getPersonagem().getVida() > 0 && computador.getPersonagem().getVida() > 0) {
            System.out.println("\nSua vez! Escolha uma ação: ");
            System.out.println("1. Atacar");
            System.out.println("2. Curar");
            int escolha = scanner.nextInt();

            if (escolha == 1) {
                usuario.atacar(computador.getPersonagem());
            } else if (escolha == 2) {
                usuario.curar();
            }

            if (computador.getPersonagem().getVida() > 0) {
                System.out.println("\nTurno do Computador!");
                int escolhaComputador = (int) (Math.random() * 2) + 1;

                if (escolhaComputador == 1) {
                    computador.atacar(usuario.getPersonagem());
                } else {
                    computador.curar();
                }
            }

            // Mostrar o status de vida
            System.out.println("\nVida do Usuário: " + usuario.getPersonagem().getVida());
            System.out.println("Vida do Computador: " + computador.getPersonagem().getVida());
        }

        // Determinar o vencedor
        if (usuario.getPersonagem().getVida() <= 0) {
            System.out.println("\nO Computador venceu!");
        } else {
            System.out.println("\nVocê venceu!");
        }

        scanner.close();
    }
}

