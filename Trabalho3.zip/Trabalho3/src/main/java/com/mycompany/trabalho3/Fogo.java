/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trabalho3;

/**
 *
 * @author riche
 */
class Fogo extends Personagem {
    public Fogo(String nome, int vida) {
        super(nome, vida);
    }

    @Override
    public void atacar(Personagem p) {
        int dano = (int) (Math.random() * 12) + 8;
        p.setVida(p.getVida() - dano);
        System.out.println(this.getNome() + " lançou uma bola de fogo em " + p.getNome() + ", causando " + dano + " de dano!");
    }
}

