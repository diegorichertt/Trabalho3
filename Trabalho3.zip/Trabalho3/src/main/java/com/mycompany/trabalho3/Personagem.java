/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.trabalho3;

/**
 *
 * @author riche
 */
// Classe abstrata
abstract class Personagem {
    private String nome;
    private int vida;

    public Personagem(String nome, int vida) {
        this.nome = nome;
        this.vida = vida;
    }

    public String getNome() {
        return nome;
    }

    public int getVida() {
        return vida;
    }

    public void setVida(int vida) {
        this.vida = vida;
    }

    // Método abstrato para ataque
    public abstract void atacar(Personagem p);

    // Método para curar com valor aleatório
    public void curar() {
        int valorCura = (int) (Math.random() * 10) + 1;
        this.vida += valorCura;
        System.out.println(nome + " curou " + valorCura + " pontos de vida!");
    }
}

